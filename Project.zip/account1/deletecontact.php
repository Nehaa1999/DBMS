<?php
require('db.php');
$t_id=$_REQUEST["id"];
$query = "DELETE FROM contact WHERE t_id=$t_id"; 
$result = mysqli_query($con,$query) or die ( mysqli_error($con));
header("Location: viewcontact.php"); 
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Login</title>
<style>
	body {
     font-family:Arial, Sans-Serif;
     text-align: center;
    background-image: url(https://media.istockphoto.com/photos/red-black-abstract-background-picture-id657982726?k=6&m=657982726&s=170667a&w=0&h=vLLskQGXusDKFu-H8B1Q5MRQ9fvJ0dlr-oh1G1_YBhE=);
     background-attachment: fixed;
  background-repeat: no-repeat;
  background-size: cover;
}
.clearfix:before, .clearfix:after{
     content: "";
     display: table;
}
.clearfix:after{
     clear: both;
}
a{
     color:#0067ab;
     text-decoration:none;
}
a:hover{
     text-decoration:underline;
}
.form{
	 text-align: left;
     width: 300px;
     margin: 0 auto;
     color: black;
}
input[type='text'], input[type='email'],
input[type='password'] {
     width: 200px;
     border-radius: 2px;
     border: 1px solid #CCC;
     padding: 10px;
     color: #333;
     width: 255px;
     font-size: 20px;
     margin-top: 10px;
     
}
 h1{
        font-size: 37px;
        
        text-transform: uppercase;
        background: -webkit-linear-gradient(black, red);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  text-align: center;
    }
input[type='submit']{
     padding: 10px 25px 8px;
     color: #fff;
     background-color: #0067ab;
     text-shadow: rgba(0,0,0,0.24) 0 1px 0;
     font-size: 16px;
     box-shadow: rgba(255,255,255,0.24) 0 2px 0 0 inset,#fff 0 1px 0 0;
     border: 1px solid #0164a5;
     border-radius: 2px;
     margin-top: 10px;
     cursor:pointer;
}
input[type='submit']:hover {
     background-color: #024978;
}
label
{
    font-size: 20px;
    text-transform: uppercase;
 
}
.container
{
    background-color: rgb(180, 180, 180);
    opacity: 0.9;
    width:310px;
    border: solid;
    border-radius: 2%;
    border-color: black;
    border-width: 3px;
    margin-left: 39%;
    margin-top: 10%;
}
h3{
    position: center;
    color: white;
    font-size: 25px;
    margin-top: 200px;
    
}
div{
    color: white;
    font-size: 25px;
}
br{
    font-size: 10px;
    color: white;
}
a{
    margin-top: 100px;
    font-size: 25px;
    position: center;
    left-margin:0px;
}
</style>

</head>
<body>
<?php
require('db.php');
session_start();
// If form submitted, insert values into the database.
if (isset($_POST['name'])){
        // removes backslashes
 $name = stripslashes($_REQUEST['name']);
        //escapes special characters in a string
 $name = mysqli_real_escape_string($con,$name);
 $password = stripslashes($_REQUEST['password']);
 $password = mysqli_real_escape_string($con,$password);
 //Checking is user existing in the database or not
        $query = "SELECT * FROM `users` WHERE name='$name'
and password='".md5($password)."'";
 $result = mysqli_query($con,$query) or die(mysql_error());
 $rows = mysqli_num_rows($result);
        if($rows==1){
     $_SESSION['name'] = $name;
            // Redirect user to index.php
     header("Location: index.php");
         }else{
 echo "<div class='form'>
<h3>Username/Password incorrect.</h3>
<br/>Click here to <a href='login.php'> Login </a></div>
<br/>Not Registered ? Click here to  <a href='registrationn.php'>Register Here for the first time</a></div>";
 }
    }else{
?>
<div class="container">
<div class="form">
<h1>Login</h1>
<form action="" method="post" name="login">
<p><label><strong>Username</strong></label> <input type="text" name="name" placeholder="Username" required /></p>
<p><label><strong>Password</strong></label> <input type="password" name="password" placeholder="Password" required /></p>
<input name="submit" type="submit" value="Login" />
</form>
<p>Not registered yet? <style> p{ font-size:19px; } </style> <a href='registrationn.php'>SIGN UP</a></p>
<p>Logged in? <a href='index.php'>Continue</a></p>

</div>
</div>
<?php } ?>
</body>
</html>
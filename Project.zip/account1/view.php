<?php
require('db.php');
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>View Records</title>
<link rel="stylesheet" href="css/style.css" />
<style>
body{
	background-image: url(https://thumbs.dreamstime.com/thumblarge_748/7489895.jpg);
	background-repeat: no-repeat;
	background-position: top;
	background-size: cover;
}
.form p{
	font-weight: bold;;
}
</style>
</head>
<body>
<div class="form">
<p><a href="dashboard.php">Dashboard</a> 
| <a href="insert.php">Book Pooja</a> 
| <a href="transport.php">Book Transport</a>
| <a href="payment.php">make payment</a>  
| <a href="logout.php">Logout</a></p>
<h2>View Booked Pooja</h2>
<table width="100%" border="1" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>S.No</strong></th>
<th><strong>User Id</strong></th>
<th><strong>Pooja Id</strong></th>
<th><strong>Name</strong></th>
<th><strong>Pooja</strong></th>
<th><strong>Date</strong></th>
<th><strong>Time</strong></th>
<th><strong>Edit</strong></th>
<th><strong>Delete</strong></th>
</tr>
</thead>
<tbody>
<?php
$count=1;
$sel_query="SELECT * FROM `pooja` WHERE submittedby='{$_SESSION['name']}';";
$result = mysqli_query($con,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr><td align="center"><?php echo $count; ?></td>
<td align="center"><?php echo $row["userid"]; ?></td>
<td align="center"><?php echo $row["pooja_id"]; ?></td>
<td align="center"><?php echo $row["name"]; ?></td>
<td align="center"><?php echo $row["pooja"]; ?></td>
<td align="center"><?php echo $row["date"]; ?></td>
<td align="center"><?php echo $row["time"]; ?></td>
<td align="center">
<a href="edit.php?id=<?php echo $row["pooja_id"]; ?>">Edit</a>
</td>
<td align="center">
<a href="delete.php?id=<?php echo $row["pooja_id"]; ?>">Delete</a>
</td>
</tr>
<?php $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>
<?php
require('db.php');
include("auth.php");
$status = "";
if(isset($_POST['new']) && $_POST['new']==1){
    $userid =$_REQUEST['userid'];
    $trn_date = date("Y-m-d H:i:s");
    $name =$_REQUEST['name'];
    $pooja = $_REQUEST['pooja'];
    $date =$_REQUEST['date'];
    $time=$_REQUEST['time'];
    $submittedby = $_SESSION["name"];
    $ins_query="insert into pooja
    (`userid`,`trn_date`,`name`,`pooja`,`date`,`time`,`submittedby`)values
    ('$userid','$trn_date','$name','$pooja','$date','$time','$submittedby')";
    mysqli_query($con,$ins_query)
    or die(mysqli_error($con));
    $status = "Pooja Booked Successfully.
    </br></br><a href='view.php'>View Booked Pooja</a>";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Book Pooja</title>
<style>
    body{
        background-image: url(https://4.bp.blogspot.com/-nIM6Tg6G-JY/WdkqOw2sjjI/AAAAAAAAAB0/0RgNoeHgx-wars6CjaDgx8RGm4uYBklvQCLcBGAs/s1600/2O3A9048%2Bas%2BSmart%2BObject-1.jpg);
        float: left;
        background-attachment: fixed;
        background-repeat: no-repeat;
        background-size: cover;
        background-size: 850px 800px;
        background-position: right;
        height: 180%;
        background-color: rgb(255,69,0);

        
    }
    input{
     width: 200px;
     border-radius: 2px;
     border: 1px solid #CCC;
     padding: 10px;
     color: #333;
     margin-left: 5px;
     margin-top: 10px;
     font-size: 15px;
     border-style: solid;
     border-radius: 5px;
     border-color: black;
    }
    input[type='date']
    {
        margin-left: 12px;
    }
    input[type='time']
    {
        margin-left: 12px;
    }
    label{
        font-size: 25px;
        margin-left: 5px;
        text-transform: uppercase;
        
        text-decoration-color: blue;
    }
    input[type='submit']{
     padding: 10px 25px 8px;
     color: #fff;
     background-color: #0067ab;
     text-shadow: rgba(0,0,0,0.24) 0 1px 0;
     font-size: 16px;
     box-shadow: rgba(255,255,255,0.24) 0 2px 0 0 inset,#fff 0 1px 0 0;
     border: 1px solid #0164a5;
     border-radius: 2px;
     margin-top: 10px;
     cursor:pointer;
     margin-left: 5px;
 }
    .form{

        color: black;
        font-size: 20px;
        position: relative;
        margin-top: 5%;
    }
     h1{
        font-size: 40px;
        text-transform: uppercase;
        
        text-decoration-color: blue;
    }
    ul{
    
    list-style-type: none;
    margin-left: 0px;
    margin-top: 3%;
    

}
ul li{
    display: inline-block;
}
ul li a{
    text-decoration: none;
    color: orange;
    padding: 8px 12px;
    border: 1px solid black;
    transition: 0.6s ease;
    font-size: 18px;
    background-color:black ;
    margin-top: 5%;


}
ul li a:hover{
    background-color: white;
    color:#000;
    transition: 0.6s ease;
}
.pooja-box
{
 max-width: 350px;
 float: none;
 margin:30px auto;
 
}

.container{
    margin-top: 5%;
    background-color:rgb(255,165,0);
    width: 825px;
    height: 703px;
    margin-left: 0px;
    

    
}
label[name="pooja"]
{    width: 200px;
     border-radius: 2px;
     border: 1px solid #CCC;
     padding: 10px;
     color: #333;
     margin-left: 5px;
     margin-top: 10px;
     font-size: 15px;
     border-style: solid;
     border-radius: 5px;
     border-color: black;
    
}
select
{
    font-size: 16px;
    border-radius: 5px;
     border: 1px solid #CCC;
     padding: 10px;
     color: #333;
     width: 205px;
}
    
</style>
</head>

<div class="main">
            <ul>
                <li><a href="page0.html">Home</a></li>
                <li><a href="page1.html">Namaste</a></li>
                <li><a href="page2.html">About</a></li>
                <li><a href="page3.html">Gallery</a></li>
                <li><a href="page5.html">Homas</a></li>
                <li><a href="page6.html">Bhajans</a></li>
                <li><a href="#">Transport</a></li>
               
                

            </ul>
        </div>  

<body>


<div class="container">
    <div class="pooja-box">
        <div class="col-md-3 pooja-left">
            <h1>Book Pooja</h1>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<p><label><strong>UserID :</strong></label> <input type="Number" name="userid" class="form-control" placeholder="Enter User ID" required /></p>
<p><label><strong>Name :</strong></label> <input type="text" name="name" class="form-control" placeholder="Enter Name" required /></p>
<p><label><strong>Pooja :</strong></label>
  <select name="pooja" placeholder="select pooja" size="1%"  required >
  <option value="Mahaganapathy homa">Mahaganapathy homa</option>
  <option value="Saraswathy Homa">Saraswathy Homa</option>
  <option value="Navachandika Homa">Navachandika Homa</option>
  <option value="Durga Homa">Durga Homa</option>
  <option value="Navagraha Homa">Navagraha Homa</option>
  <option value="Swayamvara Parvathi Homa">Swayamvara Parvathi Homa</option>
  <option value="Lakshmi Narayana Hrudaya Homa">Lakshmi Narayana Hrudaya Homa</option>
  <option value="Mruthyunjaya Homa">Mruthyunjaya Homa</option>
  <option value="Rudra Homa">Rudra Homa</option>
  <option value="Shukradithya Santhi Shanthi Homa">Shukradithya Santhi Shanthi Homa</option>
  <option value="Danwantri Homa">Danwantri Homa</option>
  <option value="Purushasooktha Homa">Purushasooktha Homa</option>
  <option value="Nithya chandika homa">Nithya chandika homa</option>
  <option value="Shani Shanthi Homa">Shani Shanthi Homa</option>
  <option value="Sarpa Shanthi Homa">Sarpa Shanthi Homa</option>
  <option value="Prathyangari homa">Prathyangari homa</option>
  <option value="Bandhidevi Havana">Bandhidevi Havana</option>
 <option value=" Ugraradha Shanthi">Ugraradha Shanthi</option>
</select> </p>

<label><strong>Date :</strong></label> <input type="date" name="date" class="form-control" placeholder="Enter date in Y-m-d format" required />
<p><label><strong>Time :</strong></label> <input type="time" name="time" class="form-control" placeholder="Enter time" required /></p>
<p><input name="submit" type="submit" value="Submit" /></p>
</form>
</div>

<div class="form">
<p><a href="dashboard.php">Dashboard</a> 
| <a href="viewuser.php">View User Details</a> 
| <a href="logout.php">Logout</a></p>
<div>
<p style="color:#FF0000;"><?php echo $status; ?></p>
</div>
</div>
</body>
</html>
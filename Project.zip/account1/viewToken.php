<?php
require('db.php');
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>View Records</title>
<link rel="stylesheet" href="css/style.css" />
<style>
body{
	background-image: url(https://image.freepik.com/free-photo/beautiful-cream-silk-texture-luxurious-satin-abstract-background-fabric-texture_55716-1433.jpg);
	background-repeat: no-repeat;
	background-position: top;
	background-size: cover;
}
.form p{
	font-weight: bold;;
}
</style>
</head>
<body>
<div class="form">
<p><a href="dashboard.php">Home</a> 
| <a href="insert.php">Insert New Record</a> 
| <a href="logout.php">Logout</a></p>
<h2>View Records</h2>
<table width="100%" border="1" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>S.No</strong></th>
<th><strong>Pooja ID</strong></th>
<th><strong>Name</strong></th>
<th><strong>Token</strong></th>
</tr>
</thead>
<tbody>
<?php
$count=1;
$sel_query="SELECT * FROM `token` WHERE name='{$_SESSION['name']}';";
$result = mysqli_query($con,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr><td align="center"><?php echo $count; ?></td>
<td align="center"><?php echo $row["pooja_id"]; ?></td>
<td align="center"><?php echo $row["name"]; ?></td>
<td align="center"><?php echo $row["id"]; ?></td>

</td>
</tr>
<?php $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>
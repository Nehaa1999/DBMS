<?php
require('db.php');
include("auth.php");
$status = "";
if(isset($_POST['new']) && $_POST['new']==1){
    $t_id = $_REQUEST['t_id'];
    $phonenumber = $_REQUEST['phonenumber'];
    $ins_query="insert into contact
    (`t_id`,`phonenumber`)values
    ('$t_id','$phonenumber')";
    mysqli_query($con,$ins_query)
    or die(mysqli_error($con));
    $status = "New Record Inserted Successfully.
    </br></br><a href='viewcontact.php'>View Record</a>
    </br></br><a href='ViewTransport.php'>View Inserted Record</a>";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Insert New Record</title>
<link rel="stylesheet" href="css/style.css" />
<style>
    body{
        background-image:url(https://media.boschsecurity.com/fs/media/pb/images/home/contact.jpg);
        float: left;
        background-attachment: fixed;
        background-repeat: no-repeat;
        background-size: cover;
        background-size: 850px 800px;
        background-position: right;
        height: 180%;
        background-color: rgb(255,69,0);

        
    }
    input{
     width: 200px;
     border-radius: 2px;
     border: 1px solid #CCC;
     padding: 10px;
     color: #333;
     margin-left: 25px;
     margin-top: 5px;
     font-size: 15px;
     border-style: solid;
     border-radius: 5px;
     border-color: black;
     position: center;
    }
   
    label{
        font-size: 25px;
        margin-left: 25px;
        text-transform: uppercase;
        position: center;

        text-decoration-color: blue;
    }
    input[type='submit']{
     padding: 10px 25px 8px;
     color: #fff;
     background-color: #0067ab;
     text-shadow: rgba(0,0,0,0.24) 0 1px 0;
     font-size: 16px;
     box-shadow: rgba(255,255,255,0.24) 0 2px 0 0 inset,#fff 0 1px 0 0;
     border: 1px solid #0164a5;
     border-radius: 2px;
     margin-top: 10px;
     cursor:pointer;
     margin-left: 25px;
 }
    .form{

        color: black;
        font-size: 20px;
        position: relative;
        margin-top: 5%;
    }
     h1{
        font-size: 40px;
        text-transform: uppercase;
        
        text-decoration-color: blue;
    }
    ul{
    
    list-style-type: none;
    margin-left: 0px;
    margin-top: 3%;
    

}
ul li{
    display: inline-block;
}
ul li a{
    text-decoration: none;
    color: orange;
    padding: 8px 12px;
    border: 1px solid black;
    transition: 0.6s ease;
    font-size: 25px;
    background-color:black ;
    margin-top: 5%;


}
ul li a:hover{
    background-color: white;
    color:#000;
    transition: 0.6s ease;
}


.container{
    margin-top: 5%;
    background-color:rgb(255,165,0);
    width: 820px;
    height: 645px;
    margin-left: 0px;
    

    
}

    
</style>
</head>
<body>
    <div class="main">
            <ul>
                <li><a href="page0.html">Home</a></li>
                <li><a href="page1.html">Namaste</a></li>
                <li><a href="page2.html">About</a></li>
                <li><a href="page3.html">Gallery</a></li>
                <li><a href="page5.html">Homas</a></li>
                <li><a href="page6.html">Bhajans</a></li>
               
               
                

            </ul>
        </div>  
<div class="form">
<p><a href="dashboard.php">Dashboard</a> 
| <a href="ViewTransport.php">View Transport Booking</a> 
| <a href="logout.php">Logout</a></p>
<div>
<div class="form">
<div class="container">
<h1>Enter Contact Details</h1>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<label>Transport ID</label>
<p><input type="Number" name="t_id" placeholder="Enter Transport ID" required /></p>
<label>Phonenumber</label>
<p><input type="Number" name="phonenumber" placeholder="Enter phonenumber" min="10"  required /></p>
<p><input name="submit" type="submit" value="Submit" /></p>
</form>
<p style="color:#FF0000;"><?php echo $status; ?></p>
</div>
</div>
</body>
</html>
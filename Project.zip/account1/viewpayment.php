<?php
require('db.php');
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>View Records</title>
<style>
body{
	background-image: url(https://cdn.hipwallpaper.com/i/81/43/5DYjQf.jpg);
	background-repeat: no-repeat;
	background-position: top;
	background-size: cover;
}
.form p{
	font-weight: bold;;
}
</style>
</head>
<body>
<div class="form">
<p><a href="index.php">Home</a> 
| <a href="token.php">GET TOKEN</a> 
| <a href="logout.php">Logout</a></p>
<h2>View Records</h2>
<table width="100%" border="1" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>S.No</strong></th>
<th><strong>User ID</strong></th>
<th><strong>Pooja_ID</strong></th>
<th><strong>Name</strong></th>
<th><strong>Card Number</strong></th>
<th><strong>Expiry Date</strong></th>
<th><strong>cvv</strong></th>
<th><strong>Card Holder Name</strong></th>
<th><strong>Transport Facility</strong></th>
<th><strong>Amount</strong></th>
<th><strong>Edit</strong></th>
<th><strong>Delete</strong></th>
</tr>
</thead>
<tbody>
<?php
$count=1;
$sel_query="SELECT * FROM `paymentt` WHERE submittedby='{$_SESSION['name']}';";
$result = mysqli_query($con,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr><td align="center"><?php echo $count; ?></td>
<td align="center"><?php echo $row["userid"]; ?></td>
<td align="center"><?php echo $row["pooja_id"]; ?></td>
<td align="center"><?php echo $row["name"]; ?></td>
<td align="center"><?php echo $row["cardnumber"]; ?></td>
<td align="center"><?php echo $row["expirydate"]; ?></td>
<td align="center"><?php echo $row["cvv"]; ?></td>
<td align="center"><?php echo $row["cardholdername"]; ?></td>
<td align="center"><?php echo $row["transport_facility"]; ?></td>
<td align="center"><?php echo $row["amount"]; ?></td>
<td align="center">
<a href="editpayment.php?id=<?php echo $row["pay_id"]; ?>">Edit</a>
</td>
<td align="center">
<a href="deletepayment.php?id=<?php echo $row["pay_id"]; ?>">Delete</a>
</td>
</tr>
<?php $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>
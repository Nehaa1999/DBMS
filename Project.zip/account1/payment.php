<?php
require('db.php');
include("auth.php");
$status = "";
if(isset($_POST['new']) && $_POST['new']==1){
    $userid =$_REQUEST['userid'];
    $pooja_id =$_REQUEST['pooja_id'];
    $trn_date = date("Y-m-d H:i:s");
    $name =$_REQUEST['name'];
    $cardnumber =$_REQUEST['cardnumber'];
    $expirydate =$_REQUEST['expirydate'];
    $cvv= $_REQUEST['cvv'];
    $cardholdername =$_REQUEST['cardholdername'];
    $transport_facility =$_REQUEST['transport_facility']; 
    $amount =$_REQUEST['amount'];
    $submittedby = $_SESSION["name"];
    $ins_query="insert into paymentt
    (`userid`,`pooja_id`,`trn_date`,`name`,`cardnumber`,`expirydate`,`cvv`,`cardholdername`,`transport_facility`,`amount`,`submittedby`)values
    ('$userid','$pooja_id','$trn_date','$name','$cardnumber','$expirydate','$cvv','$cardholdername','$transport_facility','$amount','$submittedby')";
    mysqli_query($con,$ins_query)
    or die(mysqli_error($con));
    $status = "Payment made Successfully.
    </br></br><a href='token.php'>GET TOKEN</a>
    </br></br><a href='viewpayment.php'>View payment details</a>";
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Insert Payment</title>
<style>
body{
        background-image: url(https://i2-prod.mirror.co.uk/incoming/article7121435.ece/ALTERNATES/s615b/Woman-holding-set-of-fanned-out-credit-cards.jpg);
        float: left;
        background-attachment: fixed;
        background-repeat: no-repeat;
        background-size: cover;
        background-size: 850px 800px;
        background-position: right;
        height: 180%;
        background-color: rgb(255,69,0);

        
    }
    input{
     width: 200px;
     border-radius: 2px;
     border: 1px solid #CCC;
     padding: 10px;
     color: #333;
     margin-left: 5px;
     margin-top: 5px;
     font-size: 15px;
     border-style: solid;
     border-radius: 5px;
     border-color: black;
    }
   
    label{
        font-size: 25px;
        margin-left: 5px;
        text-transform: uppercase;
        
        text-decoration-color: blue;
    }
    input[type='submit']{
     padding: 10px 25px 8px;
     color: #fff;
     background-color: #0067ab;
     text-shadow: rgba(0,0,0,0.24) 0 1px 0;
     font-size: 16px;
     box-shadow: rgba(255,255,255,0.24) 0 2px 0 0 inset,#fff 0 1px 0 0;
     border: 1px solid #0164a5;
     border-radius: 2px;
     margin-top: 10px;
     cursor:pointer;
     margin-left: 5px;
 }
    .form{

        color: black;
        font-size: 20px;
        position: relative;
        margin-top: 5%;
    }
     h1{
        font-size: 40px;
        text-transform: uppercase;
        
        text-decoration-color: blue;
    }
    ul{
    
    list-style-type: none;
    margin-left: 0px;
    margin-top: 3%;
    

}
ul li{
    display: inline-block;
}
ul li a{
    text-decoration: none;
    color: orange;
    padding: 8px 12px;
    border: 1px solid black;
    transition: 0.6s ease;
    font-size: 25px;
    background-color:black ;
    margin-top: 5%;


}
ul li a:hover{
    background-color: white;
    color:#000;
    transition: 0.6s ease;
}
.pooja-box
{
 max-width: 350px;
 float: none;
 margin:30px auto;
 
}

.container{
    margin-top: 5%;
    background-color:rgb(255,165,0);
    width: 823px;
    height: 1390px;
    margin-left: 0px;
    

    
}
label[name="pooja"]
{    width: 200px;
     border-radius: 2px;
     border: 1px solid #CCC;
     padding: 10px;
     color: #333;
     margin-left: 5px;
     margin-top: 10px;
     font-size: 15px;
     border-style: solid;
     border-radius: 5px;
     border-color: black;
    
}
select
{
    font-size: 16px;
    border-radius: 5px;
     border: 1px solid #CCC;
     padding: 10px;
     color: #333;
     width: 205px;
}
    
</style>
</head>

<body>
<div class="main">
            <ul>
                <li><a href="page0.html">Home</a></li>
                <li><a href="page1.html">Namaste</a></li>
                <li><a href="page2.html">About</a></li>
                <li><a href="page3.html">Gallery</a></li>
                <li><a href="page5.html">Homas</a></li>
                <li><a href="page6.html">Bhajans</a></li>
               
               
                

            </ul>
        </div>  
<div class="container">
    <div class="pooja-box">
        <h1>Make Payment</h1>

<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<label>user id</label>
<p><input type="text" name="userid" placeholder="Enter userid" required /></p>
<label>pooja id</label>
<p><input type="text" name="pooja_id" placeholder="Enter pooja id" required /></p>

<label>Name</label>
<p><input type="text" name="name" placeholder="Enter Name" required /></p>
<label>Card Number</label>
<p><input type="text" name="cardnumber" placeholder="xxxx-xxxx-xxxx-xxxx" required /></p>
<label>Expiry Date</label>
<p><input type="mm-yyyy" name="expirydate" placeholder="mm-yyyy" required /></p>
<label>CVV</label>
<p><input type="text" name="cvv" placeholder="Enter cvv(xxx)" required /></p>
<label>Card Holder Name</label>
<p><input type="text" name="cardholdername" placeholder="Enter cardholdername" required /></p>
<label>Transport Facility</label>
<p><input type="text" name="transport_facility" min="Yes" max="No" placeholder="Enter Yes/No" required /></p>
<label>Amount</label>
<p><input type="Number" min="1000" max="1000" name="amount" placeholder="1000" required /></p>
<p><input name="submit" type="submit" value="Submit" /></p>
</form>
<div class="form">
<p><a href="dashboard.php">Dashboard</a> 
| <a href="view.php">View Bookings</a> 
| <a href="viewpayment.php">Payment</a></p>

<div>
<p style="color:#FF0000;"><?php echo $status; ?></p>
</div>
</div>
</body>
</html>
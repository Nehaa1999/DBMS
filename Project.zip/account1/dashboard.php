<?php
require('db.php');
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Dashboard - Secured Page</title>
<style>
body{
	background-image: url(https://image.freepik.com/free-photo/soft-cloudy-is-gradient-pastel-abstract-sky-background-sweet-color_6529-1129.jpg);
	background-position: center;
	background-repeat: no-repeat;
	background-size: cover;

	}
.form{
	padding-top: 5%;
	font-size: large;
	font-weight: 800;
	font-size: 24px;
	margin-top: 0%;
}
.container{
background-color:rgb(230,230,250);
    width: 825px;
    height: 600px;
    margin-top: 2px;
    
}
	ul{
	float: center;
	list-style-type: none;
	margin-top: 35px;
	margin-left: 395px;
}
ul li{
	display: inline-block;
}
ul li a{
	text-decoration: none;
	color: white;
	padding: 5px 25px;
	border: 1px solid black;
	transition: 0.6s ease;
	font-size: 25px;
	background-color: brown;

}
ul li a:hover{
	background-color: white;
	color:#000;
	transition: 0.6s ease;
}
</style>
</head>
<body>
	<div class="main">
			<ul>
				<li><a href="page0.html">Home</a></li>
				<li><a href="page1.html">Namaste</a></li>
				<li><a href="page2.html">About</a></li>
				<li><a href="page5.html">Homas</a></li>
				<li><a href="page6.html">Bhajans</a></li>
				<li><a href="page3.html">Gallery</a></li>
			
			
				
				
				

			</ul>
		</div>	
<div class="form" align="center">
	<div class="container" align="center">
<p><h2>Welcome to Dashboard.</h2></p>
<p><a href="index.php">Home</a><p>
<p><a href="viewuser.php">User details</a><p>	
<p><a href="insert.php">Book your Pooja</a></p>
<p><a href="view.php">View my bookings</a><p>
<p><a href="transport.php">Book Transport</a><p>
	<p><a href="ViewTransport.php">View Transport</a><p>
<p><a href="payment.php">Make Payment for Booking</a></p>
<p><a href="viewpayment.php">View my payment</a><p>


	
		<p><a href="feedback.php">Feedback</a><p>
			<p><a href="logout.php">Logout</a></p>
</div>
</div>
</body>
</html>
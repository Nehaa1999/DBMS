<?php
//include auth.php file on all secure pages
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome Home</title>
<style>
	title{
		text-align: center;
		text-transform: uppercase;
		font-size: 35px;
	}
	/*a{
		text-align: center;
		font-size: 20px;
	}
	p
	{
		text-align: center;
		font-size: 25px;
	}
	.echo
	{
		font-style: italic;
	}*/
	.form1
	{
		text-align: center;
		margin-top: 13%;
		font-size: 35px;
		font-family: "Arial Black", Gadget, sans-serif;
		font-weight: bold;
		font-variant: small-caps;
	}
	button
	{
		font-size: 40px;
		width: : 40px;
		border-radius: 2%;
		border-color: black;
		background-color: #555555;
		border-style: solid;
		color: white;
	}
	body
	{
		background-image: url(https://www.pintire.com/wp-content/uploads/2019/09/2-triangles-background.png);
		background-attachment: fixed;
	background-size: cover;
	background-repeat: no-repeat; 
	}
</style>
</head>
<body>
<div class="form1">
<p>Welcome <?php echo $_SESSION['name']; ?>!</p>
<p>This is secure area.</p>
<form method="get" action="dashboard.php">
<button>Visit Dashboard</button>
</div>
</body>
</html>
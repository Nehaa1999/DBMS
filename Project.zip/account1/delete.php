<?php
require('db.php');
$pooja_id=$_REQUEST['id'];
$query = "DELETE FROM pooja WHERE pooja_id=$pooja_id"; 
$result = mysqli_query($con,$query) or die ( mysqli_error());
header("Location: view.php"); 
?>
<?php
require('db.php');
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>View Records</title>
<style>
body{
	background-image: url(https://thumbs.dreamstime.com/thumblarge_748/7489895.jpg);
	background-repeat: no-repeat;
	background-position: top;
	background-size: cover;
}
.form p{
	font-weight: bold;;
}
</style>
</head>
<body>
<div class="form">
<p><a href="index.php">Home</a> 
| <a href="insert.php">Book Pooja</a> 
| <a href="logout.php">Logout</a></p>
<h2 align="center">View details</h2>
<table width="100%" border="1" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>S.No</strong></th>
<th><strong>User Id</strong></th>
<th><strong>Name</strong></th>
<th><strong>Email</strong></th>

</tr>
</thead>
<tbody>
<?php
$count=1;
$sel_query="SELECT * FROM `users` WHERE name='{$_SESSION['name']}';";
$result = mysqli_query($con,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr><td align="center"><?php echo $count; ?></td>
<td align="center"><?php echo $row["id"]; ?></td>
<td align="center"><?php echo $row["name"]; ?></td>
<td align="center"><?php echo $row["email"]; ?></td>

</td>
<?php $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>
<?php
require('db.php');
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>View Records</title>
<link rel="stylesheet" href="css/style.css" />
<style>
body{
	background-image: url(https://media.istockphoto.com/photos/blue-soft-background-picture-id689752378?k=6&m=689752378&s=612x612&w=0&h=6KFi1iqcd5LVwA0bzgrdF1jzSK2fS6hfBqAdcNJnB-c=);
	background-repeat: no-repeat;
	background-position: top;
	background-size: cover;
}
.form p{
	font-weight: bold;;
}
</style>
</head>
<body>
<div class="form">
<p><a href="index.php">Home</a> 
| <a href="contact.php">Add Contact Details</a> 
| <a href="payment.php">Make payment</a> 
| <a href="logout.php">Logout</a></p>
<h2>View Records</h2>
<table width="100%" border="1" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>S.No</strong></th>
<th><strong>Transport ID</strong></th>
<th><strong>Pooja ID</strong>
<th><strong>Name</strong></th>
<th><strong>Number Of Members</strong></th>
<th><strong>Cab</strong></th>
<th><strong>PickUp Point</strong></th>
<th><strong>Edit</strong></th>
<th><strong>Delete</strong></th>
</tr>
</thead>
<tbody>
<?php
$count=1;
$sel_query="SELECT * FROM `transportt` WHERE submittedby='{$_SESSION['name']}';";
$result = mysqli_query($con,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr><td align="center"><?php echo $count; ?></td>
<td align="center"><?php echo $row["t_id"]; ?></td>
<td align="center"><?php echo $row["pooja_id"]; ?></td>
<td align="center"><?php echo $row["name"]; ?></td>
<td align="center"><?php echo $row["number_ofmem"]; ?></td>
<td align="center"><?php echo $row["cab"]; ?></td>
<td align="center"><?php echo $row["pickUp"]; ?></td>
<td align="center">
<a href="editTransport.php?id=<?php echo $row["t_id"]; ?>">Edit</a>
</td>
<td align="center">
<a href="deleteTransport.php?id=<?php echo $row["t_id"]; ?>">Delete</a>
</td>
</tr>

<?php $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Sign Up</title>
<style>
    h3{
        margin-top: 150px;
        font-size: 30px;
        text-transform: uppercase;
        position: center;
    }
    h1{
        font-size: 37px;
        
        text-transform: uppercase;
        background: -webkit-linear-gradient(black, red);
  -webkit-background-clip: text;
  -webkit-text-fill-color: transparent;
  text-align: center;
    }
	body {
     font-family:Arial, Sans-Serif;
     text-align: center;
     background-image: url(http://www.canadianfootclinic.ca/bg04b.jpg);
     background-attachment: fixed;
  background-repeat: no-repeat;
  background-size: cover;
}
.clearfix:before, .clearfix:after{
     content: "";
     display: table;
}
.clearfix:after{
     clear: both;
}
a{
     color:#0067ab;
     text-decoration:none;
}
a:hover{
     text-decoration:underline;
}
.form{
	 text-align: left;
     width: 300px;
     margin: 0 auto;
}
input[type='text'], input[type='email'],
input[type='password'] {
     width: 200px;
     border-radius: 2px;
     border: 1px solid #CCC;
     padding: 10px;
     color: #333;
     font-size: 14px;
     margin-top: 10px;
     font-size: 20px;
     width: 255px;
}
input[type='submit']{
     padding: 10px 25px 8px;
     color: #fff;
     background-color: #0067ab;
     text-shadow: rgba(0,0,0,0.24) 0 1px 0;
     font-size: 16px;
     box-shadow: rgba(255,255,255,0.24) 0 2px 0 0 inset,#fff 0 1px 0 0;
     border: 1px solid #0164a5;
     border-radius: 2px;
     margin-top: 10px;
     cursor:pointer;
}
.container
{
    
    background-color: rgb(180, 180, 180);
    opacity: 0.9;
    width:330px;
    border: solid;
    border-radius: 2%;
    border-color: black;
    border-width: 3px;
    margin-left: 39%;
    margin-top: 10%;
    height: 440px;

}
.form1{
    color: white;
    font-size: 30px;

}
label
{
    font-size: 20px;
    text-transform: uppercase;
 
}
input[type='submit']:hover {
     background-color: #024978;
}
</style>
</head>
<body>
<?php
require('db.php');
// If form submitted, insert values into the database.
if (isset($_REQUEST['name'])){
        // removes backslashes
 $name = stripslashes($_REQUEST['name']);
        //escapes special characters in a string
 $name = mysqli_real_escape_string($con,$name); 
 $email = stripslashes($_REQUEST['email']);
 $email = mysqli_real_escape_string($con,$email);
 $password = stripslashes($_REQUEST['password']);
 $password = mysqli_real_escape_string($con,$password);

        $query = "INSERT into `users` (name, password, email)
VALUES ('$name', '".md5($password)."', '$email')";
        $result = mysqli_query($con,$query);
        if($result){
            echo "<div class='form1'>
<h3>You are registered successfully.</h3>
<br/>Click here to <a href='login.php'>Login</a></div>";
        }
    }else{

?>

<div class="container">
<div class="form">
<h1>Sign Up</h1>
<form name="Sign Up" action="" method="post">
<p><label><strong>Username</strong></label>
<input type="text" name="name" placeholder="Username" required /></p>
<label><strong>Email</strong></label>
<div><input type="email" name="email" placeholder="Email" required /></div>
<p><label><strong>Password</strong></label>
<input type="password" name="password" placeholder="Password"  pattern=".{6,}"   required title="6 characters minimum" required/></p>
<input type="submit" name="submit" value="Sign Up" />
</form>
</div>

</div>
<?php } ?>
</body>
</html>

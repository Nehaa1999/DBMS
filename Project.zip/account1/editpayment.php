<?php
require('db.php');
include("auth.php");
$pay_id=$_REQUEST['id'];
$query = "SELECT * from paymentt where pay_id='".$pay_id."'"; 
$result = mysqli_query($con, $query) or die ( mysqli_error());
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Update Record</title>
<style>
    body{
        background-image: url(https://i2-prod.mirror.co.uk/incoming/article7121435.ece/ALTERNATES/s615b/Woman-holding-set-of-fanned-out-credit-cards.jpg);
        float: left;
        background-attachment: fixed;
        background-repeat: no-repeat;
        background-size: cover;
        background-size: 850px 800px;
        background-position: right;
        height: 180%;
        background-color: rgb(255,165,0);

        
    }
    input{
     width: 200px;
     border-radius: 2px;
     border: 1px solid #CCC;
     padding: 10px;
     color: #333;
     margin-left: 5px;
     margin-top: 10px;
     font-size: 15px;
     border-style: solid;
     border-radius: 5px;
     border-color: black;
    }
    input[type='date']
    {
        margin-left: 12px;
    }
    input[type='time']
    {
        margin-left: 12px;
    }
    label{
        font-size: 25px;
        margin-left: 5px;
        text-transform: uppercase;
        
        text-decoration-color: blue;
    }
    input[type='submit']{
     padding: 10px 25px 8px;
     color: #fff;
     background-color: #0067ab;
     text-shadow: rgba(0,0,0,0.24) 0 1px 0;
     font-size: 16px;
     box-shadow: rgba(255,255,255,0.24) 0 2px 0 0 inset,#fff 0 1px 0 0;
     border: 1px solid #0164a5;
     border-radius: 2px;
     margin-top: 10px;
     cursor:pointer;
     margin-left: 5px;
 }
    .form{

        color: black;
        font-size: 20px;
        position: relative;
        margin-top: 5%;
    }
     h1{
        font-size: 40px;
        text-transform: uppercase;
        
        text-decoration-color: blue;
    }
    ul{
    
    list-style-type: none;
    margin-left: 0px;
    margin-top: 3%;
    

}
ul li{
    display: inline-block;
}
ul li a{
    text-decoration: none;
    color: orange;
    padding: 8px 12px;
    border: 1px solid black;
    transition: 0.6s ease;
    font-size: 18px;
    background-color:black ;
    margin-top: 5%;


}
ul li a:hover{
    background-color: white;
    color:#000;
    transition: 0.6s ease;
}
.pooja-box
{
 max-width: 350px;
 float: none;
 margin:30px auto;
 
}

.container{
    margin-top: 5%;
    background-color:rgb(255,165,0);
    width: 662px;
    height: 703px;
    margin-left: 0px;
    

    
}
label[name="pooja"]
{    width: 200px;
     border-radius: 2px;
     border: 1px solid #CCC;
     padding: 10px;
     color: #333;
     margin-left: 5px;
     margin-top: 10px;
     font-size: 15px;
     border-style: solid;
     border-radius: 5px;
     border-color: black;
    
}
select
{
    font-size: 16px;
    border-radius: 5px;
     border: 1px solid #CCC;
     padding: 10px;
     color: #333;
     width: 205px;
}
.form{
	font-weight: bold;
}    
</style></head>
<body>
<div class="form">
<p><a href="dashboard.php">Dashboard</a> 
| <a href="insert.php">Insert New Record</a> 
| <a href="logout.php">Logout</a></p>
<h1>Update Record</h1>
<?php
$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$pay_id=$_REQUEST['id'];
$trn_date = date("Y-m-d H:i:s");
$name =$_REQUEST['name'];
$cardnumber =$_REQUEST['cardnumber'];
$expirydate =$_REQUEST['expirydate'];
$cvv =$_REQUEST['cvv'];
$cardholdername =$_REQUEST['cardholdername'];
$transport_facility =$_REQUEST['transport_facility'];
$amount =$_REQUEST['amount'];
$submittedby = $_SESSION["name"];
$update="update paymentt set trn_date='".$trn_date."',
name='".$name."', cardnumber='".$cardnumber."', expirydate='".$expirydate."', cvv='".$cvv."', cardholdername='".$cardholdername."', transport_facility='".$transport_facility."',amount='".$amount."',
submittedby='".$submittedby."' where pay_id='".$pay_id."'";
mysqli_query($con, $update) or die(mysqli_error());
$status = "Record Updated Successfully. </br></br>
<a href='viewpayment.php'>View Updated Record</a>";
echo '<p style="color:#FF0000;">'.$status.'</p>';
}else {
?>
<div>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<input name="pay_id" type="hidden" value="<?php echo $row['pay_id'];?>" />
<p><input type="text" name="name" placeholder="Enter Name" 
required value="<?php echo $row['name'];?>" /></p>
<p><input type="text" name="cardnumber" placeholder="Enter Card Number(xxxx-xxxx-xxxx-xxxx)" 
required value="<?php echo $row['cardnumber'];?>" /></p>
<p><input type="mm-yyyy" name="expirydate" placeholder="Enter expirydate(mm-yyyy)" 
required value="<?php echo $row['expirydate'];?>" /></p>
<p><input type="text" name="cvv" placeholder="Enter cvv" 
required value="<?php echo $row['cvv'];?>" /></p>
<p><input type="text" name="cardholdername" placeholder="Enter Cardholder Name" 
required value="<?php echo $row['cardholdername'];?>" /></p>
<p><input type="text" name="transport_facility"  min="Yes" max="No" placeholder="Enter Yes/No"  
required value="<?php echo $row['transport_facility'];?>" /></p>
<p><input type="Number" name="amount" type="Number" min="1000" max="1000" name="amount" placeholder="1000" 
required value="<?php echo $row['amount'];?>" /></p>

<p><input name="submit" type="submit" value="Update" /></p>
</form>
<?php } ?>
</div>
</div>
</body>
</html>

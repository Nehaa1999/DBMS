<?php
require('db.php');
include("auth.php");
$contact_id=$_REQUEST['id'];
$query = "SELECT * from contact where contact_id='".$contact_id."'"; 
$result = mysqli_query($con, $query) or die ( mysqli_error());
$row = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Update Record</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="dashboard.php">Dashboard</a> 
| <a href="insert.php">Insert New Record</a> 
| <a href="logout.php">Logout</a></p>
<h1>Update Record</h1>
<?php
$status = "";
if(isset($_POST['new']) && $_POST['new']==1)
{
$contact_id = $_REQUEST['id'];
$t_id = $_REQUEST['t_id'];
$phonenumber = $_REQUEST['phonenumber'];
$update="update contact set 
t_id='".$t_id."', phonenumber='".$phonenumber."' where contact_id='".$contact_id."'";
mysqli_query($con, $update) or die(mysqli_error($con));
$status = "Record Updated Successfully. </br></br>
<a href='viewcontact.php'>View Updated Record</a>";
echo '<p style="color:#FF0000;">'.$status.'</p>';
}else {
?>
<div>
<form name="form" method="post" action=""> 
<input type="hidden" name="new" value="1" />
<input name="contact_id" type="hidden" value="<?php echo $row['contact_id'];?>" />
<p><input type="Number" name="t_id" placeholder="Enter Transport ID" 
required value="<?php echo $row['t_id'];?>" /></p>
<p> <input name="Number" placeholder="Update Contact"  
required value="<?php echo $row['phonenumber'];?>" /></p>
<p><input name="submit" type="submit" value="Update" /></p>
</form>
<?php } ?>
</div>
</div>
</body>
</html>
<?php
require('db.php');
include("auth.php");
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>View Records</title>
<link rel="stylesheet" href="css/style.css" />
</head>
<body>
<div class="form">
<p><a href="index.php">Home</a> 
| <a href="contact.php">Add Contact</a> 
| <a href="ViewTransport.php">View Transport</a> 
| <a href="logout.php">Logout</a></p>
<h2>View Records</h2>
<table width="100%" border="1" style="border-collapse:collapse;">
<thead>
<tr>
<th><strong>S.No</strong></th>
<th><strong>Transport ID</strong></th>
<th><strong>Phonenumber</strong></th>
<th><strong>Delete</strong></th>
</tr>
</thead>
<tbody>
<?php
$count=1;
$sel_query="SELECT * FROM `contact` ";
$result = mysqli_query($con,$sel_query);
while($row = mysqli_fetch_assoc($result)) { ?>
<tr><td align="center"><?php echo $count; ?></td>
<td align="center"><?php echo $row["t_id"]; ?></td>
<td align="center"><?php echo $row["phonenumber"]; ?></td>
<td align="center">
<a href="deletecontact.php?id=<?php echo $row["t_id"]; ?>">Delete</a>
</td>
</tr>

<?php $count++; } ?>
</tbody>
</table>
</div>
</body>
</html>
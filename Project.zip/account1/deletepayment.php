<?php
require('db.php');

$pay_id=$_REQUEST['id'];
$query = "DELETE FROM paymentt WHERE pay_id=$pay_id"; 
$result = mysqli_query($con,$query) or die ( mysqli_error());
header("Location: viewpayment.php"); 
?>